#ifndef AStar_NodeState_h
#define AStar_NodeState_h

enum NodeState
{
    Unknown,
    Open,
    Closed
};

#endif
