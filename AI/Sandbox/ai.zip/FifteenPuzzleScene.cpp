#include "FifteenPuzzleScene.h"

FifteenPuzzleScene::FifteenPuzzleScene()
{
	AStar15 as15;
	as15.Run();
}

FifteenPuzzleScene::~FifteenPuzzleScene()
{
    
}

void FifteenPuzzleScene::OnIdle()
{

}

void FifteenPuzzleScene::OnDraw(sf::RenderWindow& renderWindow)
{
    
}