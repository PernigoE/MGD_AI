#pragma once

#include <list>
#include <iostream>

struct Node15
{
	int State[16];
	std::list<Node15*> m_aAdj;

	int m_iH;
	int m_iG;
	int m_iF;

	Node15* m_pParent;

	Node15() {};

	Node15(int* node) {
		for (int i = 0; i < 16; ++i)
		{
			State[i] = node[i];
		}

		m_iH = 0;
		m_iG = 0;
		m_iF = 0;

		m_pParent = nullptr;
	}

	bool operator==(Node15& other)
	{
		for (int i = 0; i < 16; ++i)
		{
			if (State[i] != other.State[i])
				return false;
		}
		return true;
	}

	bool operator!=(Node15& other)
	{
		return !(*this == other);
	}

	void Print()
	{
		for (int i = 0; i < 16; ++i)
		{
			std::cout << State[i] << " ";
		}
		std::cout << std::endl;
	}
};