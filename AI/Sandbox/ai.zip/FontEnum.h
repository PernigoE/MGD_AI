#ifndef FONTENUM_H
#define FONTENUM_H

enum FontEnum
{
	Font_Invalid = -1,
	Font_Consola = 0,
	
	Font_Count
};

#endif