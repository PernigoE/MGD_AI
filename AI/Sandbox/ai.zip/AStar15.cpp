#include "AStar15.h"
#include <algorithm>

void AStar15::CreateGraph()
{
	pStartNode = new Node15();
	pEndNode = new Node15();
	for (int i = 0; i < 16; ++i)
	{
		pStartNode->State[i] = i;
		pEndNode->State[i] = i;
	}
	std::swap(pStartNode->State[0], pStartNode->State[4]);
	//StartNode.State[0] = 4;
	//StartNode.State[4] = 0;

}

void AStar15::CreateGraphAdjs()
{

}

int AStar15::GetZeroPos(Node15* node)
{
	for (int i = 0; i < 16; ++i)
	{
		if (node->State[i] == 0)
			return i;
	}
}

Node15* AStar15::ZeroUp(Node15* node)
{
	int zeroRow = GetZeroPos(node) / 4;

	Node15* n = nullptr;
	if (zeroRow > 0)
	{
		n = new Node15{ *node };
		std::swap(node->State[zeroRow], node->State[zeroRow - 4]);
	}
	return n;
}

Node15* AStar15::ZeroDown(Node15* node)
{
	int zeroRow = GetZeroPos(node) / 4;

	Node15* n = nullptr;
	if (zeroRow < 3)
	{
		n = new Node15{ *node };
		std::swap(node->State[zeroRow], node->State[zeroRow + 4]);
	}
	return n;
}

Node15* AStar15::ZeroLeft(Node15* node)
{
	int zeroCol = GetZeroPos(node) % 4;

	Node15* n = nullptr;
	if (zeroCol > 0)
	{
		n = new Node15{ *node };
		std::swap(n->State[zeroCol], n->State[zeroCol - 1]);
	}
	return n;
}

Node15* AStar15::ZeroRight(Node15* node)
{
	int zeroCol = GetZeroPos(node) % 4;

	Node15* n = nullptr;
	if (zeroCol < 3)
	{
		n = new Node15{ *node };
		std::swap(n->State[zeroCol], n->State[zeroCol + 1]);
	}
	return n;
}


void AStar15::CreateNodeAdj(Node15* node)
{
	Node15* up = ZeroUp(node);
	if (up != nullptr && node->m_pParent != nullptr)
	{
		if (*up != *node->m_pParent)
		{
			node->m_aAdj.push_back(up);
		}
		else
		{
			delete  up;
		}
	}


	Node15* down = ZeroDown(node);
	if (down != nullptr && node->m_pParent != nullptr)
	{
		if (*down != *node->m_pParent)
		{
			node->m_aAdj.push_back(down);
		}
		else
		{
			delete  down;
		}
	}

	Node15* left = ZeroLeft(node);
	if (left != nullptr && node->m_pParent != nullptr)
	{
		if (*left != *node->m_pParent)
		{
			node->m_aAdj.push_back(left);
		}
		else
		{
			delete  left;
		}
	}

	Node15* right = ZeroRight(node);
	if (right != nullptr && node->m_pParent != nullptr)
	{
		if (*right != *node->m_pParent)
		{
			node->m_aAdj.push_back(right);
		}
		else
		{
			delete  right;
		}
	}
}

void AStar15::ComputeGraphHeuristics()
{

}

void AStar15::ComputeNodeHeuristic(Node15* pNode)
{
	int result = 0;
	for (int i = 0; i < 16; ++i)
	{
		int iRow = i / 4;
		int iCol = i % 4;

		int iTargetRow = pNode->State[i] / 4;
		int iTargetCol = pNode->State[i] % 4;

		result += abs(iRow - iTargetRow) + abs(iCol + iTargetCol);
	}
	pNode->m_iH = result;
}

void AStar15::Clean()
{
	qOpenList.clear();
}

void AStar15::Search()
{
	qOpenList.push_back(pStartNode);
	
	Node15* pCurrNode;
	while (!qOpenList.empty())
	{
		pCurrNode = VisitNode();
		if (*pCurrNode != *pEndNode) 
		{
			//add the almost 4 neighboar
			CreateNodeAdj(pCurrNode);
			pCurrNode->Print();

			//take the lower
			std::list<Node15*>::const_iterator it = pCurrNode->m_aAdj.begin();
			for (; it != pCurrNode->m_aAdj.end(); ++it)
			{
				//add it to open list
				AddNodeToOpenList(pCurrNode, *it);
			}
		}
		else
		{
			PrintPath(pCurrNode);
			return;
		}
	}

}

Node15* AStar15::VisitNode()
{
	Node15* minGNode = qOpenList.front();

	std::list<Node15*>::iterator index = qOpenList.begin();
	for (std::list<Node15*>::iterator it = ++qOpenList.begin(); it != qOpenList.end(); ++it)
	{
		if ((*it)->m_iF < minGNode->m_iF)
		{
			minGNode = (*it);
			index = it;
		}
	}
	qClosedList.push_back(*index);
	qOpenList.erase(index);
	return minGNode;
}

//control state, controll F
void AStar15::AddNodeToOpenList(Node15* pParent, Node15* pNode)
{
	//search the node in closed list
	std::list<Node15*>::iterator it = qClosedList.begin();
	for (; it != qClosedList.end(); ++it)
	{
		if (*(*it) == *pNode)
		{
			return;
		}
	}

	it = qOpenList.begin();
	for (; it != qOpenList.end(); ++it)
	{
		if (*(*it) == *pNode)
		{
			if (pNode->m_iG > pParent->m_iG + 1)
			{
				pNode->m_pParent = pParent;
				pNode->m_iG = pParent->m_iG + 1;
				pNode->m_iF = pNode->m_iG + pNode->m_iH;
				return;
			}
		}
	}

	ComputeNodeHeuristic(pNode);

	pNode->m_pParent = pParent;

	//weight is always 1
	pNode->m_iG = pParent->m_iG + 1;
	pNode->m_iF = pNode->m_iG + pNode->m_iH;

	qOpenList.push_back(pNode);
}

void AStar15::PrintPath(Node15* pNode) const
{

}

AStar15::AStar15()
{
	CreateGraph();
}

void AStar15::Run() {

	Search();

	//std::system("Pause");
	//Clean();
}