#include "MinerScene.h"


MinerScene::MinerScene()
{

}

MinerScene::~MinerScene()
{
    
}

void MinerScene::OnIdle()
{
	
}

void MinerScene::OnDraw(sf::RenderWindow& renderWindow)
{
    
}





