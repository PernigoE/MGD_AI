#ifndef __AStar__AStar__
#define __AStar__AStar__

#include <SFML\System.hpp>
#include <iostream>
#include <list>
#include "Node15.h"

class AStar15
{
public:
	AStar15();

    void Run();

private:
    Node15* pStartNode;
	Node15* pEndNode;
    
	int GetZeroPos(Node15*);
	Node15* ZeroUp(Node15*);
	Node15* ZeroDown(Node15*);
	Node15* ZeroLeft(Node15*);
	Node15* ZeroRight(Node15*);

    void CreateGraph();
    void CreateGraphAdjs();
	void CreateNodeAdj(Node15* node);

    
    void ComputeGraphHeuristics();
    void ComputeNodeHeuristic(Node15* pNode);
    
    void Clean();
    
    void Search();
	Node15* VisitNode();
    void AddNodeToOpenList(Node15* pParent, Node15* pNode);
    
    void PrintPath(Node15* pNode) const;
        
	std::list<Node15*> qOpenList;
	std::list<Node15*> qClosedList;

};

#endif
