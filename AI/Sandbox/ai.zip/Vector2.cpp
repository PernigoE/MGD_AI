#include "Vector2.h"

const Vector2 Vector2::ZERO(0.f, 0.f);
const Vector2 Vector2::X_VERSOR(1.f, 0.f);
const Vector2 Vector2::Y_VERSOR(0.f, 1.f);
